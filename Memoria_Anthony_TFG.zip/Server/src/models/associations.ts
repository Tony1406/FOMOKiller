import { User } from './UserModel.js';
import { Game } from './GameModel.js';
import { UserGame } from './UserGameModel.js';
import { Genre } from './GenreModel.js';
import { GameGenre } from './GameGenreModel.js';
import { Platform } from './PlatformModel.js';
import { GamePlatform } from './GamePlatformModel.js';
import { Collection } from './CollectionModel.js';
import { CollectionGame } from './CollectionGameModel.js';
import { UserPreference } from './UserPreferenceModel.js';

export const defineAssociations = () => {

    User.hasOne(UserPreference, { foreignKey: 'userId' });
    UserPreference.belongsTo(User, { foreignKey: 'userId' });

    User.belongsToMany(Game, { through: UserGame, foreignKey: 'userId', otherKey: 'gameId' });
    Game.belongsToMany(User, { through: UserGame, foreignKey: 'gameId', otherKey: 'userId' });

    User.hasMany(UserGame, { foreignKey: 'userId' });
    UserGame.belongsTo(User, { foreignKey: 'userId' });

    Game.hasMany(UserGame, { foreignKey: 'gameId' });
    UserGame.belongsTo(Game, { foreignKey: 'gameId' });

    Game.belongsToMany(Genre, { through: GameGenre, foreignKey: 'gameId', otherKey: 'genreId' });
    Genre.belongsToMany(Game, { through: GameGenre, foreignKey: 'genreId', otherKey: 'gameId' });

    Game.belongsToMany(Platform, { through: GamePlatform, foreignKey: 'gameId', otherKey: 'platformId' });
    Platform.belongsToMany(Game, { through: GamePlatform, foreignKey: 'platformId', otherKey: 'gameId' });

    Collection.belongsToMany(Game, { through: CollectionGame, foreignKey: 'collectionId', otherKey: 'gameId' });
    Game.belongsToMany(Collection, { through: CollectionGame, foreignKey: 'gameId', otherKey: 'collectionId' });
};